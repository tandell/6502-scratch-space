  "mnemonic expected",ERROR,
  "invalid extension",ERROR,
  "no space before operands",WARNING,
  "too many closing parentheses",WARNING,
  "missing closing parentheses",WARNING,
  "missing operand",ERROR,                                           /* 5 */
  "garbage at end of line",WARNING,
  "syntax error",ERROR,
  "invalid data operand",ERROR,
  ", expected",WARNING,
  "identifier expected",ERROR,                                       /* 10 */
  "directive has no effect",WARNING,
  "unexpected \"%s\" without \"%s\"",ERROR,
  "illegal section type",ERROR,
  "macro id insert on empty stack",ERROR,
  "illegal memory type",ERROR,                                       /* 15 */
  "macro id stack overflow",ERROR,
  "macro id pull without matching push",ERROR,
  "check comment",WARNING,
  "invalid numeric expansion",ERROR,
  "einline without inline",ERROR,                                    /* 20 */
  "missing %c",WARNING,
  "maximum inline nesting depth exceeded (%d)",ERROR,
  "skipping instruction in struct init",WARNING,
  "last %d bytes of string constant have been cut",WARNING,
  "conditional assembly for pass 1 is not really supported, "        /* 25 */
    "assuming true",WARNING,
  "conditional assembly for pass 2 is not really supported, assuming false",
    WARNING,
